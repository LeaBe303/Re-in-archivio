<?php
// Prevent direct script access
if ( !defined( 'ABSPATH' ) )
	die ( 'No direct script access allowed' );

/**
* 3clicks Child Theme Setup
* 
* Always use child theme if you want to make some custom modifications. 
* This way theme updates will be a lot easier.
*/
function g1_childtheme_setup() {
}

add_action( 'after_setup_theme', 'g1_childtheme_setup' );function my_custom_styles() {	wp_enqueue_style('my-custom-style2', get_stylesheet_directory_uri() . '/bootstrap.min.css');    wp_enqueue_style('my-custom-style', get_stylesheet_directory_uri() . '/main.css');}add_action('wp_enqueue_scripts', 'my_custom_styles');